import java.io.*;
import java.util.*;
import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Daemon {//this is question 2, I use simple json to parse the data and priorityqueue to sort. 
	
	/* the output of this application is:
	    id:4 name:Ian Kehoe   distance:6.555485079223217Km
		id:5 name:Nora Dempsey   distance:14.344335560203605Km
		id:6 name:Theresa Enright   distance:14.803183077865778Km
		id:8 name:Eoin Ahearn   distance:51.84544505959279Km
		id:9 name:Jack Dempsey   distance:94.49604575179136Km
		id:10 name:Georgina Gallagher   distance:90.02763856535204Km
		id:11 name:Richard Finnegan   distance:24.99359359951404Km
		id:12 name:Christina McArdle   distance:28.389070638239403Km
		id:13 name:Olive Ahearn   distance:56.19752964547596Km
		id:15 name:Michael Ahearn   distance:29.178452196328728Km
		id:17 name:Patricia Cahill   distance:62.39599976702642Km
		id:23 name:Eoin Gallagher   distance:51.472390295041166Km
		id:24 name:Rose Enright   distance:55.910697656743174Km
		id:26 name:Stephen McArdle   distance:98.53372186197271Km
		id:29 name:Oliver Ahearn   distance:65.16275878168865Km
		id:30 name:Nick Enright   distance:76.74874496848332Km
		id:31 name:Alan Behan   distance:42.32340521582316Km
		id:39 name:Lisa Ahearn   distance:24.646452552432105Km
	 */
	
	
	

	public static void main(String[] args) {
		Daemon mainfunc=new Daemon();
		mainfunc.run();
	}

	class coord{
		double longitude;
		double latitude;
		coord(double x, double y){
			this.latitude=x;
			this.longitude=y;
		}
	}
	
	class customer{
		coord loc;
		String name;
		int id;
		double dist;
		customer(coord x, String y, int z, double k){
			this.loc=x;
			this.name=y;
			this.id=z;
			this.dist=k;
		}
	}
	
	public void run(){
		try {
			JSONParser parser = new JSONParser();
			JSONArray inputArray = (JSONArray) parser.parse(new FileReader("input.txt"));//this step I add "[","]" manually to the input file to form a json array, we can also use stringbuilder append to get this done.
			PriorityQueue<customer> pq=new PriorityQueue<customer>(inputArray.size(),new Comparator<customer>(){//use head to sort the customer
				@Override
				public int compare(customer c1, customer c2){
					return c1.id-c2.id;
				}
			});
			
			coord base=new coord(-6.2592576,53.3381985);//two parameters to determine the invitation list;
			double maxDis=100;
			
			for(int i=0;i<inputArray.size();i++){
				JSONObject obj=(JSONObject) inputArray.get(i);
				double curLongitude=Double.parseDouble(obj.get("longitude").toString());
				double curLatitude=Double.parseDouble(obj.get("latitude").toString());
				coord curCoord=new coord(curLongitude,curLatitude);
				double dist=getDist(curCoord,base);
				if(maxDis>=dist) pq.offer(new customer(curCoord,obj.get("name").toString(),Integer.parseInt(obj.get("user_id").toString()),dist));//using priorityqueue to sort
			}
			
			while(!pq.isEmpty()){
				customer curr=pq.poll();
				System.out.println("id:"+curr.id+" name:"+curr.name+"   distance:"+curr.dist+"Km");
			}//this overall complexity should be O(nlogn) where n is the number of customers on the list; 
		} catch (ParseException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private double getDist(coord c1, coord c2){
		double lat1=c1.latitude;
		double lat2=c2.latitude;
		double lng1=c1.longitude;
		double lng2=c2.longitude;
		double earthRadius = 3958.75;
		double dLat = Math.toRadians(lat2-lat1);
		double dLng = Math.toRadians(lng2-lng1);
		double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
		           Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
		           Math.sin(dLng/2) * Math.sin(dLng/2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));//using formula to calculate distant.
		return earthRadius * c;
		
	}
}
